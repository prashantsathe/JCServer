
public class JCOPException extends Exception {

  public JCOPException() {

  }

  public JCOPException(String message) {
    super(message);
  }

}
